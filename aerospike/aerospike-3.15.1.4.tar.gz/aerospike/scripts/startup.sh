basedir=/home/admin/aerospike
if [ -f "$basedir/var/run/aerospike.pid" ] ;then
    PID=`cat $basedir/var/run/aerospike.pid`
    FPID=`pgrep asd`
    TPID=`pgrep telemetry.py`
    if [ "p$PID" == "p$FPID" -o "p$TPID" != "p" ] ;then
        echo "aerospike is running, please stop first !"
        exit 1
    fi
fi
nohup $basedir/modules/telemetry/telemetry.py $basedir/etc/telemetry.conf > /dev/null 2>&1 &
$basedir/bin/asd --config-file $basedir/etc/aerospike.conf
sleep 1
SPID=`pgrep asd`
if [ "p$SPID" == "p" ];then
    echo "aerospike start failed !"
    PID=`pgrep telemetry.py | grep -v grep`; if [ -n "$PID" ]; then kill $PID; fi
    exit 1 
fi
