basedir=/home/admin/aerospike
PID=`pgrep telemetry.py | grep -v grep`; if [ -n "$PID" ]; then kill $PID; fi
kill `cat /home/admin/aerospike/var/run/aerospike.pid` ; rm $basedir/var/run/aerospike.pid
